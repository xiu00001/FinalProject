package com.example.haiba.finalproject;

import android.app.Activity;
import android.os.Bundle;

public class Help_info extends Activity {

/*
This page will show the help information about the applicaiton, such as author name and instruction.
 */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_info);
    }
}
